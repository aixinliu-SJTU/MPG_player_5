#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import numpy as np
from game.game_theory import GameEnvironment
from game import make_network_n
from game.structure_mat import get_t1_matrix, cal_KR_seq
import math
from itertools import product



#==================1. Construct the subspace basis====================


player = 5

d21 = np.array([[1], [0]])
d22 = np.array([[0], [1]])

E1 = np.kron(np.ones((2, 1)), np.eye(16))
E2 = np.kron(np.eye(2), np.kron(np.ones((2, 1)), np.eye(8)))
E3 = np.kron(np.eye(4), np.kron(np.ones((2, 1)), np.eye(4)))
E4 = np.kron(np.eye(8), np.kron(np.ones((2, 1)), np.eye(2)))
E5 = np.kron(np.eye(16), np.ones((2, 1)))

EX5 = np.block([
    [np.eye(32), E1, np.zeros((32, 16)), np.zeros((32, 16)), np.zeros((32, 16)), np.zeros((32, 16))],
    [np.eye(32), np.zeros((32, 16)), E2, np.zeros((32, 16)), np.zeros((32, 16)), np.zeros((32, 16))],
    [np.eye(32), np.zeros((32, 16)), np.zeros((32, 16)), E3, np.zeros((32, 16)), np.zeros((32, 16))],
    [np.eye(32), np.zeros((32, 16)), np.zeros((32, 16)), np.zeros((32, 16)), E4, np.zeros((32, 16))],
    [np.eye(32), np.zeros((32, 16)), np.zeros((32, 16)), np.zeros((32, 16)), np.zeros((32, 16)), E5]
])



O_32 = np.zeros((32, 32))
zeros_2_5_2_4 = np.zeros((2**5, 2**4))
delta_d = d21-d22
enc_dict = {0: d21, 1:d22, 2: delta_d}


def get_hh_index(*args):
    assert len(args) == player
    
    hh = np.kron(enc_dict[args[0]], enc_dict[args[1]])
    for v in args[2:]:
        hh = np.kron(hh, enc_dict[v])
        
    return hh
    

def get_chunk(i,j):
    assert j > i, '%s %s' % (i, j)
    delta = j - i
    if delta == 1:
        chunk = [2,2]
    else:
        chunk = [0] * (delta+1)
        chunk[0] = 2
        chunk[-1] = 2
    return chunk

def set_range_and_get_vecs(m, n):
    vecs = []
    
    exist_check = {}
    for i in range(2**player):
        seq = bin(i)[2:].zfill(player)
        seq_int = list(map(int, list(seq)))
        
        seq = list(seq)
        seq[m:n+1] = ['2'] * (n+1-m)
        seq_str = ''.join(seq)
        if seq_str not in exist_check:
            exist_check[seq_str] = 1
            
            chunk = get_chunk(m,n)
            seq_int[m:n+1] = chunk
            h = get_hh_index(*seq_int)
            vecs.append(h)
        else:
            continue
    return np.concatenate(vecs, axis=-1)

segment_table = {}
start = 0

vec_mat = []
offset = 2**player
for i in range(player):

    for j in range(i+1, player):
        print(i+1,j+1)

        vecs = set_range_and_get_vecs(i,j)
        
        vecs_h = np.zeros((offset*player, vecs.shape[-1]))
        vecs_h[i*offset:(i+1)*offset] = vecs
        vecs_h[j*offset:(j+1)*offset] = -vecs
        
        vec_mat.append(vecs_h)
        
        range_ = (start, start + vecs.shape[-1])
        segment_table[range_] = (i,j)
        
        start += vecs.shape[-1]
        
vec_mat_res = np.concatenate(vec_mat,axis=-1)
print(vec_mat_res.shape)
print(vec_mat_res)


EE5 = np.asarray(EX5, dtype=float)
EE5_remove = np.delete(EE5, 15, axis=1)

print(EE5_remove)


EE5_total = np.concatenate((EE5_remove,vec_mat_res), axis=1)


np.savez('ee5_mat', EE5_total=EE5_total,segment_table=segment_table)



#================== 2. conflict connection among player ====================


# ============== payoff matrix ========================


reward_matrix_0 = np.array(
                [[0,2],
                 [0,1]]
                )

reward_matrix_1 = np.array(
                [[-1,2],
                 [0,1]]
                )

reward_matrix_2 = np.array(
                [[-2,2],
                 [0,1]]
                )

reward_matrix_3 = np.array(
                [[-2,2],
                 [0,1]]
                )

reward_matrix_4 = np.array(
                [[-2,2],
                 [0,1]]
                )


reward_mats = [reward_matrix_0, reward_matrix_1, reward_matrix_2, reward_matrix_3, reward_matrix_4]


# ===================== network =========================

network = make_network_n.create_5_net()

# ============== conflicting analysis ===================

strategy_len = reward_matrix_1.shape[-1]
num_agents = network.number_of_nodes()

max_num = strategy_len ** num_agents

assert strategy_len == 2
max_decode_length = len(bin(max_num-1)[2:]) 

env = GameEnvironment(network, strategy_len, reward_mats)

z = get_t1_matrix(env, max_num, max_decode_length)

seq, _ = cal_KR_seq(z, strategy_len)

num_agents = 5
max_strategy = 32  

payoff_matrix = np.zeros((num_agents, max_strategy))

for strategy_profile in range(1, max_strategy + 1):
   
    strategy_list = [int(x) for x in format(strategy_profile - 1, '05b')]
   
    env.reset(strategy_list)

    env.step()

    payoff_vector = env.get_payoff_vector(strategy_list)

    for player_index, payoff_value in enumerate(payoff_vector):
        payoff_matrix[player_index, strategy_profile - 1] = payoff_value

total_mat = []


for player_index, payoff_vector in enumerate(payoff_matrix):
    print(f"Player {player_index} Payoff Matrix: {payoff_vector}")
    total_mat.append(payoff_vector)
total_mat = np.concatenate(total_mat)


A = EE5_total
b = total_mat

if np.linalg.matrix_rank(A) == min(A.shape):
    x = np.linalg.solve(A, b) 
    np.save('solver_x.npy', x)  
else:
    x = np.array([])  

if x.size > 0:
    np.save('solver_x.npy', x)

start_idx = 111 
end_idx = 160
subset_x = x[start_idx:end_idx]


epsilon = 1e-11
matching_indices = np.where((subset_x < -epsilon) | (subset_x > epsilon))[0]

if matching_indices.size > 0:
    matching_indices = matching_indices + start_idx + 1  
    print("The position of the element that satisfies the condition is:", matching_indices)
else:
    print("There are no matching elements.")
    


num_blocks = 5

block_size = 160 // num_blocks

for column_i in matching_indices-1:
    column_vector = EE5_total[:, column_i]
    block_positions_with_minus_or_one = set()  
    
    for i in range(num_blocks):
        start_idx = i * block_size
        end_idx = (i + 1) * block_size
        
        block_vector = column_vector[start_idx:end_idx]
        
        if np.any(block_vector == -1) or np.any(block_vector == 1):
            block_positions_with_minus_or_one.add(i)
    
unique_block_combinations = set()

for column_i in matching_indices - 1:
    column_vector = EE5_total[:, column_i]
    block_positions_with_minus_or_one = set()  
    
    for i in range(num_blocks):
        start_idx = i * block_size
        end_idx = (i + 1) * block_size
        
        block_vector = column_vector[start_idx:end_idx]
        
        if np.any(block_vector == -1) or np.any(block_vector == 1):
            block_positions_with_minus_or_one.add(i+1) #Change the count from 0 to 1

    
    unique_block_combinations.add(frozenset(block_positions_with_minus_or_one))


for combination in unique_block_combinations:
    print(f"Players with a conflict of interest: {set(combination)}")



#================== 3. Nash equilibrium in the MPG ====================

split_VG = np.array_split(total_mat, 5)
vg1, vg2, vg3, vg4, vg5 = split_VG
cost_mat = np.vstack([vg1, vg2, vg3, vg4, vg5])

num_players = 5 
num_policies = 2

def find_nash_equilibria_5_players_v2(payoff_matrix):

    nash_equilibria = []
    num_strategies = 2
    num_players = 5
    total_combinations = num_strategies ** num_players

    def index_to_strategy(index):
        return tuple(int(digit) for digit in format(index, f'0{num_players}b'))

    for combo_index in range(total_combinations):
        current_combo = index_to_strategy(combo_index)
        is_nash = True

        for player in range(num_players):
            
            current_strategy = current_combo[player]

            current_payoff = payoff_matrix[player, combo_index]

            alternative_strategy = 1 - current_strategy
            alternative_combo = current_combo[:player] + (alternative_strategy,) + current_combo[player + 1:]
            alternative_index = int(''.join(map(str, alternative_combo)), 2)
            alternative_payoff = payoff_matrix[player, alternative_index]

            if alternative_payoff > current_payoff:
                is_nash = False
                break

        if is_nash:
            nash_equilibria.append(current_combo)

    return nash_equilibria


nash_equilibria = find_nash_equilibria_5_players_v2(cost_mat)
print(nash_equilibria)  


def son_space(dim):
    son_dim = dim // 2
    son_dim_bin_len = int(math.log(son_dim, 2))
    son_space = []
    for j in range(son_dim):
        encode_str = bin(j)[2:].zfill(son_dim_bin_len)
        son_space.append(encode_str)
    return son_space

def get_support(player_index, cols_str, cost_mat):
    def _get_insert_vec(element, original, pos):
        new_string = original[:pos] + element + original[pos:]
        col = int(new_string, 2)
        return col
    
    support_cols = []
    col_0 = _get_insert_vec('0', cols_str, player_index)
    col_1 = _get_insert_vec('1', cols_str, player_index)
    
    reward_0 = cost_mat[player_index, col_0]
    reward_1 = cost_mat[player_index, col_1]
    
    if reward_0 > reward_1:
        support_cols.append(col_0)
    elif reward_0 < reward_1:
        support_cols.append(col_1)
    else:
        support_cols.append(col_0)
        support_cols.append(col_1)
    return support_cols
    
   
def get_best_from_support(support_mat, num_players):
    sum_rows_vec = support_mat.sum(0)
    
    col_nash =  sum_rows_vec == num_players
    return col_nash
        

cost_mat_shape = cost_mat.shape
assert cost_mat_shape[0] == num_players \
    and cost_mat_shape[1] == 2 ** num_players\
        and num_policies == 2 
     
support_mat = np.zeros(cost_mat_shape)

for player_index in range(num_players):
    for cols_str in son_space(cost_mat_shape[1]):
        best_cols = get_support(player_index, cols_str, cost_mat)
        
        support_mat[player_index, best_cols] = 1

banlance_cols = get_best_from_support(support_mat, num_players)



balance_cols = get_best_from_support(support_mat, num_players)

true_indices = np.where(balance_cols)[0]
if len(true_indices) > 0:
    print("The position of pure Nash equilibrium:", true_indices+1)
else:
    print("No pure Nash equilibrium")   
    

    

#==================4. prepear for cost function in associated MPG====================


n = 5
N_1 = {2, 4, 5}
N_2 = {1, 3}


def M_1_l(l):
    if l == 1:
        return np.kron(np.ones((1, 2)), np.eye(2))
    else:
        return np.kron(np.eye(2**(l-1)), np.ones((1, 2)))


def calculate_omega_l_and_size_final(l):
    N_j = N_1 if l in N_1 else N_2
    indices = [i for i in range(1, n + 1) if i != l]
    combinations = product([1, 2], repeat=len(indices))
    omega_l = set()

    for combo in combinations:
        value = sum(((1 if (indices[i] in N_j) else combo[i]) - 1) * 2 ** (n - 2 - i) for i in range(len(indices)))
        omega_l.add(value)

    return omega_l, len(omega_l)

omega_ls_and_sizes_final = {l: calculate_omega_l_and_size_final(l) for l in range(1, n + 1)}
omega_ls_elements_final = {l: omega_ls_and_sizes_final[l][0] for l in omega_ls_and_sizes_final}
omega_ls_sizes_final = {l: omega_ls_and_sizes_final[l][1] for l in omega_ls_and_sizes_final}

formatted_output = {l: {'omega_l': omega_ls_elements_final[l], 'size': omega_ls_sizes_final[l]} 
                    for l in omega_ls_elements_final}


def extract_specific_omega_l(l):
    omega_l, size = calculate_omega_l_and_size_final(l)
    return omega_l


specific_l = 1
omega_1_specific = extract_specific_omega_l(specific_l)
specific_l = 2
omega_2_specific = extract_specific_omega_l(specific_l)
specific_l = 3
omega_3_specific = extract_specific_omega_l(specific_l)     
specific_l = 4
omega_4_specific = extract_specific_omega_l(specific_l)      
specific_l = 5
omega_5_specific = extract_specific_omega_l(specific_l)




N1 = np.block([
    [-E2, E4, zeros_2_5_2_4],
    [-E2, zeros_2_5_2_4, E5]
])

N2 = np.block([
    [-E1, E3]
])


rank1a= np.linalg.matrix_rank(N1)
rank2a= np.linalg.matrix_rank(N2)


N1_0 = N1.copy()
for j in sorted(omega_2_specific, reverse=True):  
    if j - 1 < N1_0.shape[1]:  
        N1_0 = np.delete(N1_0, j, axis=1)  
                 
N2_0 = N2.copy()
for j in sorted(omega_1_specific, reverse=True):  
    if j - 1 < N2_0.shape[1]:  
        N2_0 = np.delete(N2_0, j, axis=1)  

rank1= np.linalg.matrix_rank(N1_0)
rank2= np.linalg.matrix_rank(N2_0)


def sp(A, B):
    """
    Semi-Tensor Product of two matrices A and B.
    """
    n = A.shape[1]  # Number of columns of A
    p = B.shape[0]  # Number of rows of B

    if n == p:
        return np.dot(A, B)
    else:
        z = np.lcm(n, p)
        C = np.kron(A, np.eye(z // n)) @ np.kron(B, np.eye(z // p))
        return C


vc4 = (cost_mat[3, :] - cost_mat[1, :])
vc5 = (cost_mat[4, :] - cost_mat[1, :])
vc4T = vc4.reshape(-1, 1)
vc5T = vc5.reshape(-1, 1)
transposed_matrix_1 = np.concatenate((vc4T, vc5T), axis=0)
vd1_0 = np.linalg.inv(N1_0.T @ N1_0) @ N1_0.T @ transposed_matrix_1




vc3 = (cost_mat[2, :] - cost_mat[0, :])
vc3T = vc3.reshape(-1, 1)
transposed_matrix_2 = vc3T
vd2_0 = np.linalg.inv(N2_0.T @ N2_0) @ N2_0.T @ transposed_matrix_2



omega_2_specific_array = np.array(list(omega_2_specific), dtype=int)
vd01_1 = np.zeros((1, 16))
vd01_1[0, omega_2_specific_array] = 0
vd1_0_first = vd1_0[:12, :]
non_omega_2_specific_indices = [i for i in range(16) if i not in omega_2_specific]

for i, index in enumerate(non_omega_2_specific_indices):
    vd01_1[0, index] = vd1_0_first[i, 0]
len(non_omega_2_specific_indices)  


omega_1_specific_array = np.array(list(omega_1_specific), dtype=int)
vd02_1 = np.zeros((1, 16))
vd02_1[0, omega_1_specific_array] = 0
vd2_0_first = vd2_0[:, :8]
non_omega_1_specific_indices = [i for i in range(16) if i not in omega_1_specific]

for i, index in enumerate(non_omega_1_specific_indices):
    vd02_1[0, index] = vd2_0_first[i, 0]



#==================5. cost function in associated MPG====================

l = 2
M_1_2 = M_1_l(l)
result1 = sp(vd01_1, M_1_2)
Vp1 = vg2 - result1
print("potential function Vp1=",Vp1)



l = 1
M_1_1 = M_1_l(l)
result2 = sp(vd02_1, M_1_1)
Vp2 = vg1 - result2
print("potential function Vp2=",Vp2)

